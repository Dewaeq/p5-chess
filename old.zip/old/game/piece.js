class Piece {
    constructor(x, y, isWhite, type, taken = false, hasMoved = false) {
        this.x = x;
        this.y = y;
        this.isWhite = isWhite;
        this.type = type.toUpperCase();
        this.taken = taken;
        this.hasMoved = hasMoved;
        this.pic = this.typeToPic();
    }

    show() {
        if (this.taken) return;

        fill(this.isWhite ? "#F8F8F8" : "#565352");
        image(
            this.pic,
            this.x * tileSize,
            this.y * tileSize,
            tileSize,
            tileSize
        );
    }

    moveTo(x, y) {
        if (!this.hasMoved) this.hasMoved = true;

        this.x = x;
        this.y = y;

        // this.show();
    }

    // Set the pieces position to the first 2 values
    // of the given array [x, y]
    setPiecePosition(position) {
        if (position?.length < 2) return;

        this.x = position[0];
        this.y = position[1];
    }

    // Override this function
    getPossibleMoves(validate = true) {
        return new MoveModel();
    }

    // Straight moves
    getStraightUpMoves() {
        let moves = [];
        let moveX = this.x;

        for (let i = 1; i < this.y + 1; i++) {
            let moveY = this.y - i;

            if (mainBoard.isSquareFree(moveX, moveY)) {
                moves.push([moveX, moveY]);
            } else {
                if (this.canTake(moveX, moveY)) moves.push([moveX, moveY]);

                return moves;
            }
        }
        return moves;
    }

    getStraightRightMoves() {
        let moves = [];
        let moveY = this.y;

        for (let i = 1; i < 7 - this.x + 1; i++) {
            let moveX = this.x + i;

            if (mainBoard.isSquareFree(moveX, moveY)) {
                moves.push([moveX, moveY]);
            } else {
                if (this.canTake(moveX, moveY)) moves.push([moveX, moveY]);

                return moves;
            }
        }
        return moves;
    }

    getStraightDownMoves() {
        let moves = [];
        let moveX = this.x;

        for (let i = 1; i < 7 - this.y + 1; i++) {
            let moveY = this.y + i;

            if (mainBoard.isSquareFree(moveX, moveY)) {
                moves.push([moveX, moveY]);
            } else {
                if (this.canTake(moveX, moveY)) moves.push([moveX, moveY]);

                return moves;
            }
        }
        return moves;
    }

    getStraightLeftMoves() {
        let moves = [];
        let moveY = this.y;

        for (let i = 1; i < this.x + 1; i++) {
            let moveX = this.x - i;

            if (mainBoard.isSquareFree(moveX, moveY)) {
                moves.push([moveX, moveY]);
            } else {
                if (this.canTake(moveX, moveY)) moves.push([moveX, moveY]);

                return moves;
            }
        }
        return moves;
    }

    // Diagonal moves
    getDiagonalRightUpMoves() {
        let moves = [];
        for (let i = 1; i < 7 - this.x + 1; i++) {
            let moveX = this.x + i;
            let moveY = this.y - i;

            if (mainBoard.isSquareFree(moveX, moveY)) {
                moves.push([moveX, moveY]);
            } else {
                if (this.canTake(moveX, moveY)) moves.push([moveX, moveY]);

                return moves;
            }
        }
        return moves;
    }

    getDiagonalRightDownMoves() {
        let moves = [];
        for (let i = 1; i < 7 - this.x + 1; i++) {
            let moveX = this.x + i;
            let moveY = this.y + i;

            if (mainBoard.isSquareFree(moveX, moveY)) {
                moves.push([moveX, moveY]);
            } else {
                if (this.canTake(moveX, moveY)) moves.push([moveX, moveY]);

                return moves;
            }
        }
        return moves;
    }

    getDiagonalLeftDownMoves() {
        let moves = [];
        for (let i = 1; i < this.x + 1; i++) {
            let moveX = this.x - i;
            let moveY = this.y + i;

            if (mainBoard.isSquareFree(moveX, moveY)) {
                moves.push([moveX, moveY]);
            } else {
                if (this.canTake(moveX, moveY)) moves.push([moveX, moveY]);

                return moves;
            }
        }
        return moves;
    }

    getDiagonalLeftUpMoves() {
        let moves = [];
        for (let i = 1; i < this.x + 1; i++) {
            let moveX = this.x - i;
            let moveY = this.y - i;

            if (mainBoard.isSquareFree(moveX, moveY)) {
                moves.push([moveX, moveY]);
            } else {
                if (this.canTake(moveX, moveY)) moves.push([moveX, moveY]);

                return moves;
            }
        }
        return moves;
    }

    /// Static-ish functions, no data is modified
    //-----------------------------------------------------------------------------------------------

    clone() {
        let piece;

        if (this.type === "P") piece = new Pawn(this.x, this.y, this.isWhite, this.type, this.taken, this.hasMoved);
        else if (this.type === "N") piece = new Knight(this.x, this.y, this.isWhite, this.type, this.taken, this.hasMoved);
        else if (this.type === "B") piece = new Bishop(this.x, this.y, this.isWhite, this.type), this.taken, this.hasMoved;
        else if (this.type === "R") piece = new Rook(this.x, this.y, this.isWhite, this.type, this.taken, this.hasMoved);
        else if (this.type === "Q") piece = new Queen(this.x, this.y, this.isWhite, this.type, this.taken, this.hasMoved);
        else if (this.type === "K") piece = new King(this.x, this.y, this.isWhite, this.type, this.taken, this.hasMoved);
        else return false;

        return piece;
    }

    // Check if piece A can take piece B
    canTakePiece(pieceA, pieceB) {
        return (
            pieceA.isWhite !== pieceB.isWhite && !pieceA.taken && !pieceB.taken
        );
    }

    // Check if there is a piece we can take at
    // the provided coordinates
    canTake(takeX, takeY) {
        if (!this.withinBounds(takeX, takeY)) return false;

        // Is there a piece at that square?
        let pieceIndex = mainBoard.getIndexOfPieceAt(takeX, takeY);
        if (pieceIndex >= 0) {
            // Can we take the piece?
            if (this.canTakePiece(this, mainBoard.pieces[pieceIndex])) {
                return true;
            }
        }
        return false;
    }

    // Can we got to this square whether it is by taking
    // or if the square if free
    canMoveTo(toX, toY) {
        return this.canTake(toX, toY) || mainBoard.isSquareFree(toX, toY);
    }

    withinBounds(x, y) {
        return x >= 0 && x < 8 && y >= 0 && y < 8;
    }

    typeToPic() {
        const pieceColor = this.isWhite ? "white" : "black";
        let imgPath = `/images/${pieceColor}/`;
        switch (this.type) {
            case "K":
                return images[`${pieceColor}-king`];
            case "Q":
                return images[`${pieceColor}-queen`];
            case "R":
                return images[`${pieceColor}-rook`];
            case "B":
                return images[`${pieceColor}-bishop`];
            case "N":
                return images[`${pieceColor}-knight`];
            case "P":
                return images[`${pieceColor}-pawn`];
        }
        return loadImage(imgPath + ".svg");
    }

    getPiecePosition() {
        if (this.taken) return null;

        return [this.x, this.y];
    }
}

/// The pieces themselves
///-----------------------------------------------------------------------

class King extends Piece {
    constructor(x, y, isWhite, type, taken = false, hasMoved = false) {
        super(x, y, isWhite, type, taken, hasMoved);
    }

    getPossibleMoves(validate = true) {
        let moves = [];

        // canCastle calls board.isSquareAttacked, which in turn
        // calls king.getPossibleMoves.
        // We would be stuck in an infinite loop without this check.
        if (validate) {
            if (this.canCastleLeft()) moves.push([this.x - 2, this.y]);

            if (this.canCastleRight()) moves.push([this.x + 2, this.y]);
        }

        // Square straight above the king
        if (this.canGoToSquare(this.x, this.y - 1))
            moves.push([this.x, this.y - 1]);
        // Right up diagonal
        if (this.canGoToSquare(this.x + 1, this.y - 1))
            moves.push([this.x + 1, this.y - 1]);
        // Right straight
        if (this.canGoToSquare( this.x + 1, this.y))
            moves.push([this.x + 1, this.y]);
        // Right down diagonal
        if (this.canGoToSquare( this.x + 1, this.y + 1))
            moves.push([this.x + 1, this.y + 1]);
        // Down straight
        if (this.canGoToSquare( this.x, this.y + 1))
            moves.push([this.x, this.y + 1]);
        // Left down diagonal
        if (this.canGoToSquare( this.x - 1, this.y + 1))
            moves.push([this.x - 1, this.y + 1]);
        // Left straight
        if (this.canGoToSquare( this.x - 1, this.y))
            moves.push([this.x - 1, this.y]);
        // Left up diagonal
        if (this.canGoToSquare(this.x - 1, this.y - 1))
            moves.push([this.x - 1, this.y - 1]);

        if (validate)
            return mainBoard.validateMoves(this, moves);

        return new MoveModel(moves);
    }

    canCastleLeft() {
        if (this.hasMoved) return false;

        // Check if the rook has moved
        // We know the king hasnt moved so its safe to
        // use his coordinates
        let rookIndex = mainBoard.getIndexOfPieceAt(0, this.y);

        if (rookIndex < 0) return false;
        if (mainBoard.pieces[rookIndex].type.toUpperCase() !== "R") return false;
        if (mainBoard.pieces[rookIndex].isWhite !== this.isWhite) return false;
        if (mainBoard.pieces[rookIndex].hasMoved) return false;

        // Check if there are pieces in between
        if (mainBoard.getIndexOfPieceAt(1, this.y) >= 0) return false;
        if (mainBoard.getIndexOfPieceAt(2, this.y) >= 0) return false;
        if (mainBoard.getIndexOfPieceAt(3, this.y) >= 0) return false;

        // Check if any of the passing squares is attacked
        if (mainBoard.isSquareAttacked(1, this.y, this.isWhite, false)) return false;
        if (mainBoard.isSquareAttacked(2, this.y, this.isWhite, false)) return false;
        if (mainBoard.isSquareAttacked(3, this.y, this.isWhite, false)) return false;

        // Youre not allowed to castle when in check
        if (mainBoard.isKingInCheck(this.isWhite)) return false;

        return true;
    }

    canCastleRight() {
        if (this.hasMoved) return false;

        // Check if the rook has moved
        // We know the king hasnt moved so its safe to
        // use his coordinates
        let rookIndex = mainBoard.getIndexOfPieceAt(7, this.y);

        if (rookIndex < 0) return false;
        if (mainBoard.pieces[rookIndex].type.toUpperCase() !== "R") return false;
        if (mainBoard.pieces[rookIndex].isWhite !== this.isWhite) return false;
        if (mainBoard.pieces[rookIndex].hasMoved) return false;

        // Check if there are pieces in between
        if (mainBoard.getIndexOfPieceAt(6, this.y) >= 0) return false;
        if (mainBoard.getIndexOfPieceAt(5, this.y) >= 0) return false;

        // Check if any of the passing squares is attacked
        if (mainBoard.isSquareAttacked(6, this.y, this.isWhite, false)) return false;
        if (mainBoard.isSquareAttacked(5, this.y, this.isWhite, false)) return false;

        // Youre not allowed to castle when in check
        if (mainBoard.isKingInCheck(this.isWhite)) return false;

        return true;
    }

    canGoToSquare(moveX, moveY) {
        if (this.canTake(moveX, moveY)) return true;

        if (mainBoard.isSquareFree(moveX, moveY)) return true;

        return false;
    }
}

class Queen extends Piece {
    constructor(x, y, isWhite, type, taken = false, hasMoved = false) {
        super(x, y, isWhite, type, taken, hasMoved);
    }

    getPossibleMoves(validate = true) {
        let moves = [];

        // Straight moves
        moves.push(...this.getStraightUpMoves());
        moves.push(...this.getStraightRightMoves());
        moves.push(...this.getStraightDownMoves());
        moves.push(...this.getStraightLeftMoves());

        // Diagonal moves
        moves.push(...this.getDiagonalRightUpMoves());
        moves.push(...this.getDiagonalLeftUpMoves());
        moves.push(...this.getDiagonalRightDownMoves());
        moves.push(...this.getDiagonalLeftDownMoves());

        if (validate)
            return mainBoard.validateMoves(this, moves);

        return new MoveModel(moves);
    }
}

class Rook extends Piece {
    constructor(x, y, isWhite, type, taken = false, hasMoved = false) {
        super(x, y, isWhite, type, taken, hasMoved);
    }

    getPossibleMoves(validate = true) {
        let moves = [];

        moves.push(...this.getStraightUpMoves());
        moves.push(...this.getStraightRightMoves());
        moves.push(...this.getStraightDownMoves());
        moves.push(...this.getStraightLeftMoves());

        if (validate)
            return mainBoard.validateMoves(this, moves);

        return new MoveModel(moves);
    }
}

class Bishop extends Piece {
    constructor(x, y, isWhite, type, taken = false, hasMoved = false) {
        super(x, y, isWhite, type, taken, hasMoved);
    }

    getPossibleMoves(validate = true) {
        let moves = [];

        moves.push(...this.getDiagonalRightUpMoves());
        moves.push(...this.getDiagonalLeftUpMoves());
        moves.push(...this.getDiagonalRightDownMoves());
        moves.push(...this.getDiagonalLeftDownMoves());

        if (validate)
            return mainBoard.validateMoves(this, moves);

        return new MoveModel(moves);
    }
}

class Knight extends Piece {
    constructor(x, y, isWhite, type, taken = false, hasMoved = false) {
        super(x, y, isWhite, type, taken, hasMoved);
    }

    getPossibleMoves(validate = true) {
        let moves = [];

        // Right up
        if (this.canMoveTo(this.x + 1, this.y - 2)) {
            moves.push([this.x + 1, this.y - 2]);
        }
        // Middle right up
        if (this.canMoveTo(this.x + 2, this.y - 1)) {
            moves.push([this.x + 2, this.y - 1]);
        }
        // Middle right down
        if (this.canMoveTo(this.x + 2, this.y + 1)) {
            moves.push([this.x + 2, this.y + 1]);
        }
        // Right down
        if (this.canMoveTo(this.x + 1, this.y + 2)) {
            moves.push([this.x + 1, this.y + 2]);
        }
        // Left down
        if (this.canMoveTo(this.x - 1, this.y + 2)) {
            moves.push([this.x - 1, this.y + 2])
        }
        // Middle left down
        if (this.canMoveTo(this.x - 2, this.y + 1)) {
            moves.push([this.x - 2, this.y + 1]);
        }
        // Middle left up
        if (this.canMoveTo(this.x - 2, this.y - 1)) {
            moves.push([this.x - 2, this.y - 1]);
        }
        // Left up
        if (this.canMoveTo(this.x - 1, this.y - 2)) {
            moves.push([this.x - 1, this.y - 2]);
        }

        if (validate)
            return mainBoard.validateMoves(this, moves);

        return new MoveModel(moves);
    }
}

class Pawn extends Piece {
    constructor(x, y, isWhite, type, taken = false, hasMoved = false) {
        super(x, y, isWhite, type, taken, hasMoved);
    }

    getPossibleMoves(validate = true) {
        let moves = [];
        const direction = this.getPawnDirection();

        // Check if there's a piece in front of us
        if (this.canForward())
            moves.push([this.x, this.y + direction]);

        // Check if we can go 2 squares forward
        if (this.canDoubleForward())
            moves.push([this.x, this.y + direction * 2]);

        // Check if we can take a piece
        // if yes, add the returned move to the list
        if (this.canTake(this.x + 1, this.y + direction))
            moves.push([this.x + 1, this.y + direction]);
        if (this.canTake(this.x - 1, this.y + direction))
            moves.push([this.x - 1, this.y + direction]);

        if (validate)
            return mainBoard.validateMoves(this, moves);

        return new MoveModel(moves);
    }

    canForward() {
        let direction = this.getPawnDirection();
        return mainBoard.getIndexOfPieceAt(this.x, this.y + direction) < 0;
    }

    canDoubleForward() {
        const inStartPos = this.isWhite ? this.y === 6 : this.y === 1;
        const direction = this.getPawnDirection();
        const onePlaceAhead = this.canForward(mainBoard);
        const twoPlacesAhead = mainBoard.isSquareFree(this.x, this.y + direction * 2);

        return inStartPos && onePlaceAhead && twoPlacesAhead;
    }

    getPawnDirection() {
        return this.isWhite ? -1 : 1;
    }
}
