class Engine {

    generateMoves(board, isWhite) {
        // let pieces = mainBoard.pieces.filter(piece => !piece.taken && piece.isWhite === isWhite);
        const pieces = board.pieces;
        let moves = [];

        for (let i = 0; i < pieces.length; i++) {
            if (pieces[i].taken || pieces[i].isWhite !== isWhite) continue;

            let pieceMoves = pieces[i].getPossibleMoves(board).allowedMoves;
            moves.push(...pieceMoves);
        }

        return moves;
    }

    evaluateBoard(board) {
        if (board.pieces[board.whKingInd].taken) {
            return Number.NEGATIVE_INFINITY;
            console.log("oh ow");
        }
        if (board.pieces[board.blKingInd].taken) {
            console.log("oh ow");
            return Number.POSITIVE_INFINITY;
        }

        let sum = 0;
        let blackMaterial = 0;
        let whiteMaterial = 0;
        let blackPositional = 0;
        let whitePositional = 0;

        for (let i = 0; i < board.pieces.length; i++) {
            const piece = board.pieces[i];
            if (piece.taken || piece.x < 0 || piece.y < 0) {
                continue;
            }

            blackMaterial += VALUE_MAP[piece.type] || 0;
            whiteMaterial += VALUE_MAP[piece.type] || 0;
            blackPositional += POSITIONAL_VALUE[false][piece.type][piece.y][piece.x];
            whitePositional += POSITIONAL_VALUE[true][piece.type][piece.y][piece.x];

            // Add the pieces value to the sum
            /* if (piece.isWhite) sum += VALUE_MAP[piece.type];
            else sum -= VALUE_MAP[piece.type];

            // Add the positional values to the sum
            if (piece.isWhite) {
                try {
                    sum += POSITIONAL_VALUE[true][piece.type][piece.y][piece.x];
                } catch(e) {
                    console.error(e);
                    console.log(board.pieces);
                    console.log(piece);
                }
            } else {
                try {
                    sum -= POSITIONAL_VALUE[false][piece.type][piece.y][piece.x];
                } catch (e) {
                    console.error(e);
                    console.log(piece);
                }
            }*/
        }

        const materialDifference = blackMaterial - whiteMaterial;

        const positionalDifference = blackPositional - whitePositional;

        return materialDifference + positionalDifference;
        return sum;
    }

    evaluateMove(move, board) {
        board.movePiece(move[2], move[0], move[1]);

        if (board.pieces[board.blKingInd].taken) console.log("fking bs");
        if (board.pieces[board.whKingInd].taken) console.log("fking white bs");

        return this.evaluateBoard(board);
    }

    minimax(board, depth, alpha, beta, isMaximizing, isWhite) {
        if (depth === 0) {
            const sum = this.evaluateBoard(board);
            return [null, sum];
        }

        let bestMove = null;
        let bestMoveValue = isMaximizing ? Number.NEGATIVE_INFINITY : Number.POSITIVE_INFINITY;

        const moves = engine.generateMoves(board, isWhite);

        // Sort moves randomly, so the same move isn't always picked on ties
        moves.sort(() => 0.5 - Math.random());

        for (let i = 0; i < moves.length; i++) {
            const move = moves[i];
            const newBoard = board.clone();
            newBoard.testMove(move[2], move[0], move[1], newBoard);
            const [childBestMove, childValue] = this.minimax(newBoard, depth - 1, alpha, beta, !isMaximizing, isWhite);

            if (isMaximizing) {
                if (childValue > bestMoveValue) {
                    bestMoveValue = childValue;
                    bestMove = move;
                }
                alpha = Math.max(alpha, childValue);
            } else {
                if (childValue < bestMoveValue) {
                    bestMoveValue = childValue;
                    bestMove = move;
                }
                beta = Math.min(beta, childValue);
            }

            //Alpha-beta pruning. Amazing how simple it is.
            if (beta <= alpha) {
                break;
            }
        }

        return [bestMove || moves[0], bestMoveValue];
    }
}